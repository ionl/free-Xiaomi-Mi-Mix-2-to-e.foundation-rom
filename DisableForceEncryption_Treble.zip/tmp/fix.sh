#!/sbin/sh 
tmpzipdir=/tmp;
i=$tmpzipdir/fefix.zip
metadir=META-INF/com/google/android;

find /vendor/etc -name "fstab.*" -exec sed -i 's/discard,//g' {} +
find /vendor/etc -name "fstab.*" -exec sed -i 's/errors=panic//g' {} +
find /vendor/etc -name "fstab.*" -exec sed -i 's/forceencrypt/encryptable/g' {} +
find /vendor/etc -name "fstab.*" -exec sed -i 's/forcefdeorfbe/encryptable/g' {} +
find /vendor/etc -name "fstab.*" -exec sed -i 's/fileencryption/encryptable/g' {} +

unzip "$i" -d "$tmpzipdir" "$metadir/*";
chmod 755 "$tmpzipdir/$metadir/update-binary";
"$tmpzipdir/$metadir/update-binary" 1 1 "$i";